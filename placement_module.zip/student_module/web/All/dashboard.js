function myFunction() {
    // var bo=document.body.getElementbyclassName(bottom-container);
    // var bs=document.getElementsByClassName("bottom-container");
    // bs.style.background="black";
var element = document.body;

element.classList.toggle("dark-mode");

}
function help(){
var help1=document.getElementsByClassName("que");
help1.classList.toggle("que");

}
